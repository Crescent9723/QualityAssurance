import java.io.*;
import java.util.*;

public class Script {
	private static String paraString = "sio.loadmat(";
	
	public static void main(String args[]) {
		File file = new File("testCases.txt");
		FileReader reader = null;
		PrintWriter writerScript = null;
		PrintWriter writerCompare = null;
		int counter = 0;

		try {
			reader = new FileReader(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		try {
			writerScript = new PrintWriter("Script.bat", "UTF-8");
		} catch (FileNotFoundException | UnsupportedEncodingException e2) {
			e2.printStackTrace();
		}

		try (BufferedReader bufferReader = new BufferedReader(reader)) {
			String line;
			while ((line = bufferReader.readLine()) != null) {
				Scanner lineScanner = new Scanner(line);
				lineScanner.useDelimiter(",");
				counter ++;
				
				String inputFileName = lineScanner.next();
				String dict = lineScanner.next();
				String append = lineScanner.next();
				String byteOrder = lineScanner.next();
				String dtype = lineScanner.next();
				String squeeze = lineScanner.next();
				String chars = lineScanner.next();
				String compatible = lineScanner.next();
				String struct = lineScanner.next();
				String verify = lineScanner.next();
				String varNames = lineScanner.next();
				
				if (inputFileName.equals("valid"))
					inputFileName = new String("valid.mat");
				if (inputFileName.equals("invalid"))
					inputFileName = new String("invalid.mat");	
				if (inputFileName.equals("empty_file"))
					inputFileName = new String("empty.mat");

				if (dict.equals("valid"))
					dict = new String("[np.array([[1,2], [3,4]])");
				if (dict.equals("invalid"))
					dict = new String("[]");	
				if (dict.equals("empty_dict"))
					dict = new String("[np.array([])]");

				if (varNames.equals("valid_single"))
					varNames = new String("{'a'}");
				if (varNames.equals("invalid"))
					varNames = new String("{'///'}");	
				if (varNames.equals("valid_multiple"))
					varNames = new String("{'a', 'b'}");
				if (varNames.equals("none"))
					varNames = new String("None");
				
				
				paraString += inputFileName + ", ";
				paraString += dict + ", ";
				paraString += append + ", ";
				paraString += byteOrder + ", ";
				paraString += dtype + ", ";
				paraString += squeeze + ", ";
				paraString += chars + ", ";
				paraString += compatible + ", ";
				paraString += struct + ", ";
				paraString += verify + ", ";
				paraString += varNames + ")";
				
				writerScript.println(paraString);
				lineScanner.close();
				paraString = "sio.loadmat(";
			}
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		writerScript.close();
		writerCompare.close();
	}
}
